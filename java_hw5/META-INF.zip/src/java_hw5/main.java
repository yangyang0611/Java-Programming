package java_hw5;
import java.util.Scanner;

public class main {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		String input1 = keyboard.next();
		String input2 = keyboard.next();
		email e = new email();
		document d = new document();	
		file f = new file();
		
		if(input2.equals("Email")) {
			e.setSender(keyboard.nextLine());
			e.setRecipient(keyboard.nextLine());
			e.setTitle(keyboard.nextLine());
			e.setText(keyboard.nextLine());
		}
		
		if(input2.equals("Document")) {
			d.setText(keyboard.nextLine());
		}
			
		if(input2.equals("File")) {
			f.setPathname(keyboard.nextLine());
			f.setText(keyboard.nextLine());
		}
		
		if(input1.equals("A")) {
			if(input2.equals("Email"))
				System.out.println(e.toString());
			else if(input2.equals("Document"))
				System.out.println(d.toString());
			else if(input2.equals("File"))
				System.out.println(f.toString());
		}
		
		if(input1.equals("B")) {
			String check = keyboard.nextLine();
			if(input2.equals("Email")) {
				String[] array = e.toString().split(" ");
				boolean key = false;
				for(String x : array) {
					if(x.equals(check)) {
						key = true;
						break;
					}
				}
				System.out.print(key);
			}
			else if(input2.equals("Document")) {
				String[] array = d.toString().split(" ");
				boolean key = false;
				for(String x : array) {
					if(x.equals(check)) {
						key = true;
						break;
					}
				}
				System.out.print(key);
			}
			else if(input2.equals("File")) {
				String[] array = f.toString().split(" ");
				boolean key = false;
				for(String x : array) {
					if(x.equals(check)) {
						key = true;
						break;
					}
				}
				System.out.print(key);
			}
		}
		
		if(input1.equals("C")) {
			if(input2.equals("Email")) {
				String text = keyboard.nextLine();
				String change = keyboard.nextLine();
				if(text.equals("text")) {
					e.setText(change);
				}
				else if(text.equals("sender")) {
					e.setSender(change);
				}
				else if(text.equals("recipient")) {
					e.setRecipient(change);
				}
				else if(text.equals("title")) {
					e.setTitle(change);
				}
			System.out.println(e.toString());
			}		
			
			else if(input2.equals("Document")) {
				String text = keyboard.nextLine();
				String change = keyboard.nextLine();
				if(text.equals("text"))
					d.setText(change);
				System.out.println(d.toString());
			}
			
			else if (input2.equals("File")) {
				String text = keyboard.nextLine();
				String change = keyboard.nextLine();
				if(text.equals("text")) {
					f.setText(change);
				}
				else if(text.equals("pathname")) {
					f.setPathname(change);
				}
				System.out.println(f.toString());
			}
		}
		keyboard.close();
	}
}