package java_hw5;

public class document {
	protected String text;
	
	public document() {}                      // default constructor
	
	public void setText(String newText) {   // save text content
		text = newText;
	}
	
	public String toString() {                // return text content
		return text;
	}
}
