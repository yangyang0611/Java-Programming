package java_hw7_1;

public class Product {
	private String name;
	private int cost;
	private float weight;
	private Department department;
}
