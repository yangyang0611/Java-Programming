package classsmate;

public class Document {
	public String text;

	public Document() {}

 
	public String toString() {

		return text;
	}

	public void setText(String SText) {

		text = SText;
	}
}
